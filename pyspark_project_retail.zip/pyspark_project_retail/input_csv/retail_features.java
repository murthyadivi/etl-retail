// ORM class for table 'retail_features'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Mon Feb 17 11:19:29 UTC 2020
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class retail_features extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("store", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        store = (Integer)value;
      }
    });
    setters.put("date", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        date = (String)value;
      }
    });
    setters.put("temperature", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        temperature = (String)value;
      }
    });
    setters.put("fuel_prize", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        fuel_prize = (String)value;
      }
    });
    setters.put("markdown1", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        markdown1 = (String)value;
      }
    });
    setters.put("markdown2", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        markdown2 = (String)value;
      }
    });
    setters.put("markdown3", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        markdown3 = (String)value;
      }
    });
    setters.put("markdown4", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        markdown4 = (String)value;
      }
    });
    setters.put("markdown5", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        markdown5 = (String)value;
      }
    });
    setters.put("cpi", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        cpi = (String)value;
      }
    });
    setters.put("unemployment", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        unemployment = (String)value;
      }
    });
    setters.put("isholiday", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        isholiday = (String)value;
      }
    });
    setters.put("check_date", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        check_date = (java.sql.Timestamp)value;
      }
    });
  }
  public retail_features() {
    init0();
  }
  private Integer store;
  public Integer get_store() {
    return store;
  }
  public void set_store(Integer store) {
    this.store = store;
  }
  public retail_features with_store(Integer store) {
    this.store = store;
    return this;
  }
  private String date;
  public String get_date() {
    return date;
  }
  public void set_date(String date) {
    this.date = date;
  }
  public retail_features with_date(String date) {
    this.date = date;
    return this;
  }
  private String temperature;
  public String get_temperature() {
    return temperature;
  }
  public void set_temperature(String temperature) {
    this.temperature = temperature;
  }
  public retail_features with_temperature(String temperature) {
    this.temperature = temperature;
    return this;
  }
  private String fuel_prize;
  public String get_fuel_prize() {
    return fuel_prize;
  }
  public void set_fuel_prize(String fuel_prize) {
    this.fuel_prize = fuel_prize;
  }
  public retail_features with_fuel_prize(String fuel_prize) {
    this.fuel_prize = fuel_prize;
    return this;
  }
  private String markdown1;
  public String get_markdown1() {
    return markdown1;
  }
  public void set_markdown1(String markdown1) {
    this.markdown1 = markdown1;
  }
  public retail_features with_markdown1(String markdown1) {
    this.markdown1 = markdown1;
    return this;
  }
  private String markdown2;
  public String get_markdown2() {
    return markdown2;
  }
  public void set_markdown2(String markdown2) {
    this.markdown2 = markdown2;
  }
  public retail_features with_markdown2(String markdown2) {
    this.markdown2 = markdown2;
    return this;
  }
  private String markdown3;
  public String get_markdown3() {
    return markdown3;
  }
  public void set_markdown3(String markdown3) {
    this.markdown3 = markdown3;
  }
  public retail_features with_markdown3(String markdown3) {
    this.markdown3 = markdown3;
    return this;
  }
  private String markdown4;
  public String get_markdown4() {
    return markdown4;
  }
  public void set_markdown4(String markdown4) {
    this.markdown4 = markdown4;
  }
  public retail_features with_markdown4(String markdown4) {
    this.markdown4 = markdown4;
    return this;
  }
  private String markdown5;
  public String get_markdown5() {
    return markdown5;
  }
  public void set_markdown5(String markdown5) {
    this.markdown5 = markdown5;
  }
  public retail_features with_markdown5(String markdown5) {
    this.markdown5 = markdown5;
    return this;
  }
  private String cpi;
  public String get_cpi() {
    return cpi;
  }
  public void set_cpi(String cpi) {
    this.cpi = cpi;
  }
  public retail_features with_cpi(String cpi) {
    this.cpi = cpi;
    return this;
  }
  private String unemployment;
  public String get_unemployment() {
    return unemployment;
  }
  public void set_unemployment(String unemployment) {
    this.unemployment = unemployment;
  }
  public retail_features with_unemployment(String unemployment) {
    this.unemployment = unemployment;
    return this;
  }
  private String isholiday;
  public String get_isholiday() {
    return isholiday;
  }
  public void set_isholiday(String isholiday) {
    this.isholiday = isholiday;
  }
  public retail_features with_isholiday(String isholiday) {
    this.isholiday = isholiday;
    return this;
  }
  private java.sql.Timestamp check_date;
  public java.sql.Timestamp get_check_date() {
    return check_date;
  }
  public void set_check_date(java.sql.Timestamp check_date) {
    this.check_date = check_date;
  }
  public retail_features with_check_date(java.sql.Timestamp check_date) {
    this.check_date = check_date;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof retail_features)) {
      return false;
    }
    retail_features that = (retail_features) o;
    boolean equal = true;
    equal = equal && (this.store == null ? that.store == null : this.store.equals(that.store));
    equal = equal && (this.date == null ? that.date == null : this.date.equals(that.date));
    equal = equal && (this.temperature == null ? that.temperature == null : this.temperature.equals(that.temperature));
    equal = equal && (this.fuel_prize == null ? that.fuel_prize == null : this.fuel_prize.equals(that.fuel_prize));
    equal = equal && (this.markdown1 == null ? that.markdown1 == null : this.markdown1.equals(that.markdown1));
    equal = equal && (this.markdown2 == null ? that.markdown2 == null : this.markdown2.equals(that.markdown2));
    equal = equal && (this.markdown3 == null ? that.markdown3 == null : this.markdown3.equals(that.markdown3));
    equal = equal && (this.markdown4 == null ? that.markdown4 == null : this.markdown4.equals(that.markdown4));
    equal = equal && (this.markdown5 == null ? that.markdown5 == null : this.markdown5.equals(that.markdown5));
    equal = equal && (this.cpi == null ? that.cpi == null : this.cpi.equals(that.cpi));
    equal = equal && (this.unemployment == null ? that.unemployment == null : this.unemployment.equals(that.unemployment));
    equal = equal && (this.isholiday == null ? that.isholiday == null : this.isholiday.equals(that.isholiday));
    equal = equal && (this.check_date == null ? that.check_date == null : this.check_date.equals(that.check_date));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof retail_features)) {
      return false;
    }
    retail_features that = (retail_features) o;
    boolean equal = true;
    equal = equal && (this.store == null ? that.store == null : this.store.equals(that.store));
    equal = equal && (this.date == null ? that.date == null : this.date.equals(that.date));
    equal = equal && (this.temperature == null ? that.temperature == null : this.temperature.equals(that.temperature));
    equal = equal && (this.fuel_prize == null ? that.fuel_prize == null : this.fuel_prize.equals(that.fuel_prize));
    equal = equal && (this.markdown1 == null ? that.markdown1 == null : this.markdown1.equals(that.markdown1));
    equal = equal && (this.markdown2 == null ? that.markdown2 == null : this.markdown2.equals(that.markdown2));
    equal = equal && (this.markdown3 == null ? that.markdown3 == null : this.markdown3.equals(that.markdown3));
    equal = equal && (this.markdown4 == null ? that.markdown4 == null : this.markdown4.equals(that.markdown4));
    equal = equal && (this.markdown5 == null ? that.markdown5 == null : this.markdown5.equals(that.markdown5));
    equal = equal && (this.cpi == null ? that.cpi == null : this.cpi.equals(that.cpi));
    equal = equal && (this.unemployment == null ? that.unemployment == null : this.unemployment.equals(that.unemployment));
    equal = equal && (this.isholiday == null ? that.isholiday == null : this.isholiday.equals(that.isholiday));
    equal = equal && (this.check_date == null ? that.check_date == null : this.check_date.equals(that.check_date));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.store = JdbcWritableBridge.readInteger(1, __dbResults);
    this.date = JdbcWritableBridge.readString(2, __dbResults);
    this.temperature = JdbcWritableBridge.readString(3, __dbResults);
    this.fuel_prize = JdbcWritableBridge.readString(4, __dbResults);
    this.markdown1 = JdbcWritableBridge.readString(5, __dbResults);
    this.markdown2 = JdbcWritableBridge.readString(6, __dbResults);
    this.markdown3 = JdbcWritableBridge.readString(7, __dbResults);
    this.markdown4 = JdbcWritableBridge.readString(8, __dbResults);
    this.markdown5 = JdbcWritableBridge.readString(9, __dbResults);
    this.cpi = JdbcWritableBridge.readString(10, __dbResults);
    this.unemployment = JdbcWritableBridge.readString(11, __dbResults);
    this.isholiday = JdbcWritableBridge.readString(12, __dbResults);
    this.check_date = JdbcWritableBridge.readTimestamp(13, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.store = JdbcWritableBridge.readInteger(1, __dbResults);
    this.date = JdbcWritableBridge.readString(2, __dbResults);
    this.temperature = JdbcWritableBridge.readString(3, __dbResults);
    this.fuel_prize = JdbcWritableBridge.readString(4, __dbResults);
    this.markdown1 = JdbcWritableBridge.readString(5, __dbResults);
    this.markdown2 = JdbcWritableBridge.readString(6, __dbResults);
    this.markdown3 = JdbcWritableBridge.readString(7, __dbResults);
    this.markdown4 = JdbcWritableBridge.readString(8, __dbResults);
    this.markdown5 = JdbcWritableBridge.readString(9, __dbResults);
    this.cpi = JdbcWritableBridge.readString(10, __dbResults);
    this.unemployment = JdbcWritableBridge.readString(11, __dbResults);
    this.isholiday = JdbcWritableBridge.readString(12, __dbResults);
    this.check_date = JdbcWritableBridge.readTimestamp(13, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(store, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(date, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(temperature, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(fuel_prize, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown1, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown2, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown3, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown4, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown5, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(cpi, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(unemployment, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(isholiday, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(check_date, 13 + __off, 93, __dbStmt);
    return 13;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(store, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(date, 2 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(temperature, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(fuel_prize, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown1, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown2, 6 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown3, 7 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown4, 8 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(markdown5, 9 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(cpi, 10 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(unemployment, 11 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(isholiday, 12 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(check_date, 13 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.store = null;
    } else {
    this.store = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.date = null;
    } else {
    this.date = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.temperature = null;
    } else {
    this.temperature = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.fuel_prize = null;
    } else {
    this.fuel_prize = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.markdown1 = null;
    } else {
    this.markdown1 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.markdown2 = null;
    } else {
    this.markdown2 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.markdown3 = null;
    } else {
    this.markdown3 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.markdown4 = null;
    } else {
    this.markdown4 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.markdown5 = null;
    } else {
    this.markdown5 = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.cpi = null;
    } else {
    this.cpi = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.unemployment = null;
    } else {
    this.unemployment = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.isholiday = null;
    } else {
    this.isholiday = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.check_date = null;
    } else {
    this.check_date = new Timestamp(__dataIn.readLong());
    this.check_date.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.store) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.store);
    }
    if (null == this.date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, date);
    }
    if (null == this.temperature) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, temperature);
    }
    if (null == this.fuel_prize) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, fuel_prize);
    }
    if (null == this.markdown1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown1);
    }
    if (null == this.markdown2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown2);
    }
    if (null == this.markdown3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown3);
    }
    if (null == this.markdown4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown4);
    }
    if (null == this.markdown5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown5);
    }
    if (null == this.cpi) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, cpi);
    }
    if (null == this.unemployment) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, unemployment);
    }
    if (null == this.isholiday) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, isholiday);
    }
    if (null == this.check_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.check_date.getTime());
    __dataOut.writeInt(this.check_date.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.store) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.store);
    }
    if (null == this.date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, date);
    }
    if (null == this.temperature) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, temperature);
    }
    if (null == this.fuel_prize) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, fuel_prize);
    }
    if (null == this.markdown1) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown1);
    }
    if (null == this.markdown2) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown2);
    }
    if (null == this.markdown3) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown3);
    }
    if (null == this.markdown4) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown4);
    }
    if (null == this.markdown5) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, markdown5);
    }
    if (null == this.cpi) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, cpi);
    }
    if (null == this.unemployment) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, unemployment);
    }
    if (null == this.isholiday) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, isholiday);
    }
    if (null == this.check_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.check_date.getTime());
    __dataOut.writeInt(this.check_date.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(store==null?"null":"" + store, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(date==null?"null":date, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(temperature==null?"null":temperature, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(fuel_prize==null?"null":fuel_prize, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown1==null?"null":markdown1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown2==null?"null":markdown2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown3==null?"null":markdown3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown4==null?"null":markdown4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown5==null?"null":markdown5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(cpi==null?"null":cpi, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(unemployment==null?"null":unemployment, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(isholiday==null?"null":isholiday, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(check_date==null?"null":"" + check_date, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(store==null?"null":"" + store, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(date==null?"null":date, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(temperature==null?"null":temperature, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(fuel_prize==null?"null":fuel_prize, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown1==null?"null":markdown1, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown2==null?"null":markdown2, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown3==null?"null":markdown3, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown4==null?"null":markdown4, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(markdown5==null?"null":markdown5, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(cpi==null?"null":cpi, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(unemployment==null?"null":unemployment, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(isholiday==null?"null":isholiday, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(check_date==null?"null":"" + check_date, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.store = null; } else {
      this.store = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.date = null; } else {
      this.date = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.temperature = null; } else {
      this.temperature = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.fuel_prize = null; } else {
      this.fuel_prize = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown1 = null; } else {
      this.markdown1 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown2 = null; } else {
      this.markdown2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown3 = null; } else {
      this.markdown3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown4 = null; } else {
      this.markdown4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown5 = null; } else {
      this.markdown5 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.cpi = null; } else {
      this.cpi = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.unemployment = null; } else {
      this.unemployment = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.isholiday = null; } else {
      this.isholiday = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.check_date = null; } else {
      this.check_date = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.store = null; } else {
      this.store = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.date = null; } else {
      this.date = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.temperature = null; } else {
      this.temperature = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.fuel_prize = null; } else {
      this.fuel_prize = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown1 = null; } else {
      this.markdown1 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown2 = null; } else {
      this.markdown2 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown3 = null; } else {
      this.markdown3 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown4 = null; } else {
      this.markdown4 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.markdown5 = null; } else {
      this.markdown5 = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.cpi = null; } else {
      this.cpi = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.unemployment = null; } else {
      this.unemployment = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.isholiday = null; } else {
      this.isholiday = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.check_date = null; } else {
      this.check_date = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    retail_features o = (retail_features) super.clone();
    o.check_date = (o.check_date != null) ? (java.sql.Timestamp) o.check_date.clone() : null;
    return o;
  }

  public void clone0(retail_features o) throws CloneNotSupportedException {
    o.check_date = (o.check_date != null) ? (java.sql.Timestamp) o.check_date.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("store", this.store);
    __sqoop$field_map.put("date", this.date);
    __sqoop$field_map.put("temperature", this.temperature);
    __sqoop$field_map.put("fuel_prize", this.fuel_prize);
    __sqoop$field_map.put("markdown1", this.markdown1);
    __sqoop$field_map.put("markdown2", this.markdown2);
    __sqoop$field_map.put("markdown3", this.markdown3);
    __sqoop$field_map.put("markdown4", this.markdown4);
    __sqoop$field_map.put("markdown5", this.markdown5);
    __sqoop$field_map.put("cpi", this.cpi);
    __sqoop$field_map.put("unemployment", this.unemployment);
    __sqoop$field_map.put("isholiday", this.isholiday);
    __sqoop$field_map.put("check_date", this.check_date);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("store", this.store);
    __sqoop$field_map.put("date", this.date);
    __sqoop$field_map.put("temperature", this.temperature);
    __sqoop$field_map.put("fuel_prize", this.fuel_prize);
    __sqoop$field_map.put("markdown1", this.markdown1);
    __sqoop$field_map.put("markdown2", this.markdown2);
    __sqoop$field_map.put("markdown3", this.markdown3);
    __sqoop$field_map.put("markdown4", this.markdown4);
    __sqoop$field_map.put("markdown5", this.markdown5);
    __sqoop$field_map.put("cpi", this.cpi);
    __sqoop$field_map.put("unemployment", this.unemployment);
    __sqoop$field_map.put("isholiday", this.isholiday);
    __sqoop$field_map.put("check_date", this.check_date);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}

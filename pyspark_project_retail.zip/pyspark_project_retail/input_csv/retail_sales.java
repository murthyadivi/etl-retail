// ORM class for table 'retail_sales'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Mon Feb 17 11:10:28 UTC 2020
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class retail_sales extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  public static interface FieldSetterCommand {    void setField(Object value);  }  protected ResultSet __cur_result_set;
  private Map<String, FieldSetterCommand> setters = new HashMap<String, FieldSetterCommand>();
  private void init0() {
    setters.put("store", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        store = (Integer)value;
      }
    });
    setters.put("dept", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        dept = (Integer)value;
      }
    });
    setters.put("sale_date", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        sale_date = (String)value;
      }
    });
    setters.put("weekly_sales", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        weekly_sales = (String)value;
      }
    });
    setters.put("isholiday", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        isholiday = (String)value;
      }
    });
    setters.put("check_date", new FieldSetterCommand() {
      @Override
      public void setField(Object value) {
        check_date = (java.sql.Timestamp)value;
      }
    });
  }
  public retail_sales() {
    init0();
  }
  private Integer store;
  public Integer get_store() {
    return store;
  }
  public void set_store(Integer store) {
    this.store = store;
  }
  public retail_sales with_store(Integer store) {
    this.store = store;
    return this;
  }
  private Integer dept;
  public Integer get_dept() {
    return dept;
  }
  public void set_dept(Integer dept) {
    this.dept = dept;
  }
  public retail_sales with_dept(Integer dept) {
    this.dept = dept;
    return this;
  }
  private String sale_date;
  public String get_sale_date() {
    return sale_date;
  }
  public void set_sale_date(String sale_date) {
    this.sale_date = sale_date;
  }
  public retail_sales with_sale_date(String sale_date) {
    this.sale_date = sale_date;
    return this;
  }
  private String weekly_sales;
  public String get_weekly_sales() {
    return weekly_sales;
  }
  public void set_weekly_sales(String weekly_sales) {
    this.weekly_sales = weekly_sales;
  }
  public retail_sales with_weekly_sales(String weekly_sales) {
    this.weekly_sales = weekly_sales;
    return this;
  }
  private String isholiday;
  public String get_isholiday() {
    return isholiday;
  }
  public void set_isholiday(String isholiday) {
    this.isholiday = isholiday;
  }
  public retail_sales with_isholiday(String isholiday) {
    this.isholiday = isholiday;
    return this;
  }
  private java.sql.Timestamp check_date;
  public java.sql.Timestamp get_check_date() {
    return check_date;
  }
  public void set_check_date(java.sql.Timestamp check_date) {
    this.check_date = check_date;
  }
  public retail_sales with_check_date(java.sql.Timestamp check_date) {
    this.check_date = check_date;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof retail_sales)) {
      return false;
    }
    retail_sales that = (retail_sales) o;
    boolean equal = true;
    equal = equal && (this.store == null ? that.store == null : this.store.equals(that.store));
    equal = equal && (this.dept == null ? that.dept == null : this.dept.equals(that.dept));
    equal = equal && (this.sale_date == null ? that.sale_date == null : this.sale_date.equals(that.sale_date));
    equal = equal && (this.weekly_sales == null ? that.weekly_sales == null : this.weekly_sales.equals(that.weekly_sales));
    equal = equal && (this.isholiday == null ? that.isholiday == null : this.isholiday.equals(that.isholiday));
    equal = equal && (this.check_date == null ? that.check_date == null : this.check_date.equals(that.check_date));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof retail_sales)) {
      return false;
    }
    retail_sales that = (retail_sales) o;
    boolean equal = true;
    equal = equal && (this.store == null ? that.store == null : this.store.equals(that.store));
    equal = equal && (this.dept == null ? that.dept == null : this.dept.equals(that.dept));
    equal = equal && (this.sale_date == null ? that.sale_date == null : this.sale_date.equals(that.sale_date));
    equal = equal && (this.weekly_sales == null ? that.weekly_sales == null : this.weekly_sales.equals(that.weekly_sales));
    equal = equal && (this.isholiday == null ? that.isholiday == null : this.isholiday.equals(that.isholiday));
    equal = equal && (this.check_date == null ? that.check_date == null : this.check_date.equals(that.check_date));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.store = JdbcWritableBridge.readInteger(1, __dbResults);
    this.dept = JdbcWritableBridge.readInteger(2, __dbResults);
    this.sale_date = JdbcWritableBridge.readString(3, __dbResults);
    this.weekly_sales = JdbcWritableBridge.readString(4, __dbResults);
    this.isholiday = JdbcWritableBridge.readString(5, __dbResults);
    this.check_date = JdbcWritableBridge.readTimestamp(6, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.store = JdbcWritableBridge.readInteger(1, __dbResults);
    this.dept = JdbcWritableBridge.readInteger(2, __dbResults);
    this.sale_date = JdbcWritableBridge.readString(3, __dbResults);
    this.weekly_sales = JdbcWritableBridge.readString(4, __dbResults);
    this.isholiday = JdbcWritableBridge.readString(5, __dbResults);
    this.check_date = JdbcWritableBridge.readTimestamp(6, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(store, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(dept, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(sale_date, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(weekly_sales, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(isholiday, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(check_date, 6 + __off, 93, __dbStmt);
    return 6;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(store, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(dept, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(sale_date, 3 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(weekly_sales, 4 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeString(isholiday, 5 + __off, 12, __dbStmt);
    JdbcWritableBridge.writeTimestamp(check_date, 6 + __off, 93, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.store = null;
    } else {
    this.store = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.dept = null;
    } else {
    this.dept = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.sale_date = null;
    } else {
    this.sale_date = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.weekly_sales = null;
    } else {
    this.weekly_sales = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.isholiday = null;
    } else {
    this.isholiday = Text.readString(__dataIn);
    }
    if (__dataIn.readBoolean()) { 
        this.check_date = null;
    } else {
    this.check_date = new Timestamp(__dataIn.readLong());
    this.check_date.setNanos(__dataIn.readInt());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.store) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.store);
    }
    if (null == this.dept) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.dept);
    }
    if (null == this.sale_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, sale_date);
    }
    if (null == this.weekly_sales) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, weekly_sales);
    }
    if (null == this.isholiday) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, isholiday);
    }
    if (null == this.check_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.check_date.getTime());
    __dataOut.writeInt(this.check_date.getNanos());
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.store) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.store);
    }
    if (null == this.dept) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.dept);
    }
    if (null == this.sale_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, sale_date);
    }
    if (null == this.weekly_sales) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, weekly_sales);
    }
    if (null == this.isholiday) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, isholiday);
    }
    if (null == this.check_date) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.check_date.getTime());
    __dataOut.writeInt(this.check_date.getNanos());
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(store==null?"null":"" + store, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dept==null?"null":"" + dept, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(sale_date==null?"null":sale_date, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(weekly_sales==null?"null":weekly_sales, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(isholiday==null?"null":isholiday, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(check_date==null?"null":"" + check_date, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(store==null?"null":"" + store, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(dept==null?"null":"" + dept, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(sale_date==null?"null":sale_date, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(weekly_sales==null?"null":weekly_sales, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(isholiday==null?"null":isholiday, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(check_date==null?"null":"" + check_date, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 44, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.store = null; } else {
      this.store = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dept = null; } else {
      this.dept = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.sale_date = null; } else {
      this.sale_date = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.weekly_sales = null; } else {
      this.weekly_sales = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.isholiday = null; } else {
      this.isholiday = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.check_date = null; } else {
      this.check_date = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.store = null; } else {
      this.store = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.dept = null; } else {
      this.dept = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.sale_date = null; } else {
      this.sale_date = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.weekly_sales = null; } else {
      this.weekly_sales = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null")) { this.isholiday = null; } else {
      this.isholiday = __cur_str;
    }

    __cur_str = __it.next();
    if (__cur_str.equals("null") || __cur_str.length() == 0) { this.check_date = null; } else {
      this.check_date = java.sql.Timestamp.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    retail_sales o = (retail_sales) super.clone();
    o.check_date = (o.check_date != null) ? (java.sql.Timestamp) o.check_date.clone() : null;
    return o;
  }

  public void clone0(retail_sales o) throws CloneNotSupportedException {
    o.check_date = (o.check_date != null) ? (java.sql.Timestamp) o.check_date.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new HashMap<String, Object>();
    __sqoop$field_map.put("store", this.store);
    __sqoop$field_map.put("dept", this.dept);
    __sqoop$field_map.put("sale_date", this.sale_date);
    __sqoop$field_map.put("weekly_sales", this.weekly_sales);
    __sqoop$field_map.put("isholiday", this.isholiday);
    __sqoop$field_map.put("check_date", this.check_date);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("store", this.store);
    __sqoop$field_map.put("dept", this.dept);
    __sqoop$field_map.put("sale_date", this.sale_date);
    __sqoop$field_map.put("weekly_sales", this.weekly_sales);
    __sqoop$field_map.put("isholiday", this.isholiday);
    __sqoop$field_map.put("check_date", this.check_date);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if (!setters.containsKey(__fieldName)) {
      throw new RuntimeException("No such field:"+__fieldName);
    }
    setters.get(__fieldName).setField(__fieldVal);
  }

}
